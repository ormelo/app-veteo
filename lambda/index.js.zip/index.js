var fkClient = new client({
    trackingId:"attiristf",
    token:"1b6372cefdf64b2cbe7c5d8491d2f528",
},"json");

exports.handler = async (event) => {
    // TODO implement
    const response = {
        statusCode: 200,
        body: event["queryStringParameters"]["q"],
    };
    let body = "";
    if (event.body !== null && event.body !== undefined) {
        body = JSON.parse(event.body)
        //your code
    }
    fkClient.doKeywordSearch("mobiles under 8000",10).then(function(value){
        console.log(value); //object with status, error and body
    });
    console.log('body.... ', event["queryStringParameters"]["q"]);
    return response;
};
