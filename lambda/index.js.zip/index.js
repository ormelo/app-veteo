var client = require('flipkart-api-affiliate-client');
var uuid = require('uuid-v4');
var http = require("https");
var request = require("request");
var DEVELOPER_ACCESS_TOKEN = '7311e67496773579a7924b37e2086b32e68de0a0298890ae236b598d507f0b40';

var fkClient = new client({
    trackingId:"attiristf",
    token:"1b6372cefdf64b2cbe7c5d8491d2f528",
},"json");

var myUUID = uuid();
 

exports.handler = async (event, context, callback) => {
    // TODO implement
    const response = {
        statusCode: 200,
        body: event["queryStringParameters"]["q"],
    };
    let body = "";
    if (event.body !== null && event.body !== undefined) {
        body = JSON.parse(event.body)
        //your code
    }
    
    
            //return;
    
    var myProm = new Promise(function(resolve, reject){
     
            var storyId = 'test';
            var integrationId = '';
            var integrationScript = undefined;
            console.log('myUUID: ',myUUID);
        
            var options = {
                "method": "POST",
                "hostname": "api.chatbot.com",
                "port": null,
                "path": "/stories",
                "headers": {
                    "content-type": "application/json",
                    "authorization": "Bearer "+DEVELOPER_ACCESS_TOKEN
                }
            };

            request.post({url:'http://api.chatbot.com', options}, function(err,httpResponse,body){ 
                console.log('resp body: ', body);
                resolve("true");
             })
              
            /*var req = http.request(options, function (res) {
                
            var chunks = [];
            res.on("data", function (chunk) {
                
                chunks.push(chunk);
            });
    
            console.log('reuqest made to:', options);
    
            res.on("end", function () {
                var respBody = Buffer.concat(chunks);
                console.log('resp body: ', respBody.toString());
                storyId = JSON.parse(respBody.toString()).id;
                console.log('storyId: ', storyId);
                let output = {
                    statusCode: 200,
                    body: storyId
                 };
                resolve(storyId);
            });
         });
         
         req.write("{\"name\":\""+myUUID+"\",\"description\":\"\"}");
         req.end();*/
          
            
     })
.then(function(result){
  // Success so do something with result
  let output = {
                statusCode: 200,
                body: result,
             };
  callback(undefined, output);
  console.log("Success:", result)
})
    
    
     /*var req = http.request(options, function (res) {
        var chunks = [];
        console.log('htt request made... ', http);
        res.on("data", function (chunk) {
            console.log('data: ', chunk);
            chunks.push(chunk);
        });

        console.log('reuqest made to:', options);

        res.on("end", function () {
            var body = Buffer.concat(chunks);
            console.log('resp body: ', body.toString());
            storyId = JSON.parse(body.toString()).id;
            console.log('storyId: ', storyId);
            let output = {
                statusCode: 200,
                body: storyId,
             };
            callback(undefined, output)
        });
     });
     
     req.write("{\"name\":\""+myUUID+"\",\"description\":\"\"}");
     req.end();*/
    
    /*return fkClient.doKeywordSearch(event["queryStringParameters"]["q"],10).then(function(value){
        console.log('shpng response.... ', value);
        let output = {
            statusCode: 200,
            body: JSON.parse(value.body).products[0].productBaseInfoV1.productId,
        };
        callback(undefined, output)
    });*/
};
